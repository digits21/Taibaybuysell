<footer>
			<div class="footer-top">
				<div class="container">
					<div class="foo-grids">
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Who We Are</h4>
							<p> We are just two computer science student who thought it would be awesome if you could easily sell your unsed stuff online </p>
							<p> of give them away if they no more woth anything for you but could be handy for others </p>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Help</h4>
							<ul>
								<li><a href="howitworks.php">How it Works</a></li>						
								<li><a href="sitemap.php">Sitemap</a></li>
								<li><a href="faq.php">Faq</a></li>
								<li><a href="feedback.php">Feedback</a></li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="typography.php">Shortcodes</a></li>
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Information</h4>
							<ul>
								<li><a href="region.php">Locations Map</a></li>	
								<li><a href="terms.php">Terms of Use</a></li>
								<li><a href="popular-search.php">Popular searches</a></li>	
								<li><a href="privacy.php">Privacy Policy</a></li>	
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Contact Us</h4>
							<span class="hq">Our headquarters</span>
							<address>
								<ul class="location">
									<li><span class="glyphicon glyphicon-map-marker"></span></li>
									<li>Hsinchu East District 300</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-earphone"></span></li>
									<li>+886 975 344 147</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-envelope"></span></li>
									<li><a href="mailto:ouedmenga@gmail.com">ouedmenga@gmail.com</a></li>
									<div class="clearfix"></div>
								</ul>						
							</address>
						</div>
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="footer-bottom text-center">
			<div class="container">
				<div class="footer-logo">
					<a href="index.php"><span>T</span>SHED</a>
				</div>
				<div class="footer-social-icons">
				
					<ul>
						<li><a class="facebook" href="#"><span>Facebook</span></a></li>
						<li><a class="twitter" href="#"><span>Twitter</span></a></li>
						<li><a class="flickr" href="#"><span>Flickr</span></a></li>
						<li><a class="googleplus" href="#"><span>Google+</span></a></li>
						<li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
					</ul>
				</div>
				<div class="copyrights">
					<p> © 2016 TSHED. All Rights Reserved | Design by  <a href="http://tshed.com"> TSHED</a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>