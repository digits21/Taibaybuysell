<footer class="diff">
			   <p class="text-center">&copy 2016 TSHED. All Rights Reserved | Design by <a href="https://tshed.com" target="_blank">TSHED.</a></p>
			</footer>