
<form method="post" action="send.php">
    <input type="text" value="example@gmail.com" name="verify"/>
    <input type="submit" value="send" name="submit"/>
    
</form>
 