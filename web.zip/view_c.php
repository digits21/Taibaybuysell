<div class="view-controls-list" id="viewcontrols">
									<label>view :</label>
									<!--<a class="gridview"><i class="glyphicon glyphicon-th"></i></a>-->
									<a class="listview active"><i class="glyphicon glyphicon-th-list"></i></a>
								</div>